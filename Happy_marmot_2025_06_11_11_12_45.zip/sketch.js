let trator;
let velocidade = 3;
let obstaculos = [];
let entregas = 0;
let maxObstaculos = 5;
let largura = 600, altura = 400;

function setup() {
  createCanvas(largura, altura);
  trator = createVector(50, altura / 2);
  for (let i = 0; i < maxObstaculos; i++) {
    obstaculos.push(createVector(random(150, largura - 50), random(50, altura - 50)));
  }
}

function draw() {
  background(120, 180, 100); // campo verde
  
  // Desenhar cidade
  fill(150);
  rect(largura - 100, 0, 100, altura);

  // Desenhar trator
  fill(255, 0, 0);
  rect(trator.x, trator.y, 40, 30);

  // Desenhar obstáculos
  fill(100, 50, 0);
  obstaculos.forEach(o => {
    ellipse(o.x, o.y, 30, 30);
  });

  // Movimentação
  if (keyIsDown(LEFT_ARROW)) trator.x -= velocidade;
  if (keyIsDown(RIGHT_ARROW)) trator.x += velocidade;
  if (keyIsDown(UP_ARROW)) trator.y -= velocidade;
  if (keyIsDown(DOWN_ARROW)) trator.y += velocidade;

  // Limites
  trator.x = constrain(trator.x, 0, largura - 40);
  trator.y = constrain(trator.y, 0, altura - 30);

  // Colisão com obstáculos
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    if (dist(trator.x + 20, trator.y + 15, obstaculos[i].x, obstaculos[i].y) < 30) {
      // Remove obstáculo e penaliza
      obstaculos.splice(i, 1);
      entregas = max(0, entregas - 1);
      console.log('Colidiu com obstáculo! Penalidade aplicada.');
    }
  }

  // Entrega na cidade
  if (trator.x + 40 > largura - 100) {
    entregas++;
    trator.x = 50;  // volta para o campo
    trator.y = altura / 2;
    // Adiciona novos obstáculos
    obstaculos.push(createVector(random(150, largura - 150), random(50, altura - 50)));
    console.log('Entrega feita! Total:', entregas);
  }

  // Exibir placar
  fill(0);
  textSize(20);
  text('Entregas: ' + entregas, 10, 30);
}
